import javax.swing.JOptionPane;

public class Principal {

	public static void main(String[] args) {

		Paciente p1 = new Paciente();
		p1.getValoresPaciente();
		JOptionPane.showMessageDialog(null, p1.diagnostico(), "Paciente 1", JOptionPane.INFORMATION_MESSAGE);
				
		Paciente p2 = new Paciente();
		p2.getValoresPaciente();
		JOptionPane.showMessageDialog(null, p2.diagnostico(), "Paciente 2", JOptionPane.INFORMATION_MESSAGE);
				
		Paciente p3 = new Paciente();
		p3.getValoresPaciente();
		JOptionPane.showMessageDialog(null, p3.diagnostico(), "Paciente 3", JOptionPane.INFORMATION_MESSAGE);
		
		
	}

}
