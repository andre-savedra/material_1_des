public class Personagens {
     String raca;
     int vida, ataque, defesa;
     boolean premium;
     
     public Personagens(String raca, 
            int vida, int ataque, int defesa, boolean premium) {

        this.raca = raca;
        this.vida = vida;
        this.ataque = ataque;
        this.defesa = defesa;
        this.premium = premium;
     }


}
