import javax.swing.JOptionPane;

public class Principal {

	public static void main(String[] args) {

		Paciente p1 = new Paciente(51.5, 1.56);
		JOptionPane.showMessageDialog(null, p1.diagnostico(), "Paciente 1", JOptionPane.INFORMATION_MESSAGE);
				
		Paciente p2 = new Paciente(80.1, 1.75);
		JOptionPane.showMessageDialog(null, p2.diagnostico(), "Paciente 2", JOptionPane.INFORMATION_MESSAGE);
				
		Paciente p3 = new Paciente(50.8, 1.65);
		JOptionPane.showMessageDialog(null, p3.diagnostico(), "Paciente 3", JOptionPane.INFORMATION_MESSAGE);
		
		
	}

}
