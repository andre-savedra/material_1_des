import java.text.DecimalFormat;

public class Paciente {

	double peso, altura, IMC;
	String diagnostico;

	public Paciente(double peso, double altura) {
		this.peso = peso;
		this.altura = altura;
	}

	public double calcularIMC() {
		IMC = (peso / (altura * altura));
		return IMC;
	}

	String diagnostico() {

		calcularIMC();

		if (IMC < 16) 
			diagnostico = "Baixo peso muito grave";
		 else if (IMC < 17) 
			diagnostico = "Baixo peso grave";
		 else if (IMC < 18.5) 
			diagnostico = "Baixo peso";
		 else if (IMC < 25) 
			diagnostico = "Peso normal";
		 else if (IMC < 30) 
			diagnostico = "Sobrepeso";
		 else if (IMC < 35) 
			diagnostico = "Obesidade grau I";
		 else if (IMC < 40) 
			diagnostico = "Obesidade grau II";
		 else 
			diagnostico = "Obesidade grau III (obesidade mórbida)";
		
		DecimalFormat df = new DecimalFormat("###.##");

		return ("Paciente com: " + diagnostico + " ! IMC de: " + df.format(IMC));

	}

}
